import { NgModule } from '@angular/core';
import { AngularScaffoldComponent } from './angular-scaffold.component';



@NgModule({
  declarations: [
    AngularScaffoldComponent
  ],
  imports: [
  ],
  exports: [
    AngularScaffoldComponent
  ]
})
export class AngularScaffoldModule { }
