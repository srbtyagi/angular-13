import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-angular-scaffold',
  template: `
    <p>
      angular-scaffold works!
    </p>
  `,
  styles: [
  ]
})
export class AngularScaffoldComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
