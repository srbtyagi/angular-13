import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularScaffoldComponent } from './angular-scaffold.component';

describe('AngularScaffoldComponent', () => {
  let component: AngularScaffoldComponent;
  let fixture: ComponentFixture<AngularScaffoldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AngularScaffoldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularScaffoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
