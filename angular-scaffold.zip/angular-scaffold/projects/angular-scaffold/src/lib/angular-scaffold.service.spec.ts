import { TestBed } from '@angular/core/testing';

import { AngularScaffoldService } from './angular-scaffold.service';

describe('AngularScaffoldService', () => {
  let service: AngularScaffoldService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AngularScaffoldService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
