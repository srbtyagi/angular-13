/*
 * Public API Surface of angular-scaffold
 */

export * from './lib/angular-scaffold.service';
export * from './lib/angular-scaffold.component';
export * from './lib/angular-scaffold.module';
